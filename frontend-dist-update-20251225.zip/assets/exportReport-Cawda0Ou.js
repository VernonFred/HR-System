import x from"./html2canvas.esm-CBrSDip1.js";import{E as m}from"./index-Z4KlEyq3.js";const y=e=>({"E-I":"外向-内向","S-N":"感觉-直觉","T-F":"思考-情感","J-P":"判断-知觉"})[e]||e,b=e=>({D:"支配型",I:"影响型",S:"稳健型",C:"谨慎型"})[e]||e,h=e=>e?new Date(e).toLocaleString("zh-CN"):"-",u=e=>{const t=e.result_details||{},r=e.candidate_name||"未知",l=e.candidate_phone||"-",g=e.questionnaire_name||"测评问卷",s=e.questionnaire_type||"CUSTOM";let n="";if(t.mbti_type){const a=t.mbti_dimensions||{};n=`
      <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 12px; color: white; margin-bottom: 30px;">
        <div style="display: flex; align-items: center; gap: 20px;">
          <div style="font-size: 48px; font-weight: bold;">${t.mbti_type}</div>
          <div>
            <div style="font-size: 24px; font-weight: bold;">${t.mbti_description||"MBTI人格类型"}</div>
            <div style="opacity: 0.9; margin-top: 5px;">MBTI人格类型测评</div>
          </div>
        </div>
      </div>
      
      <div style="margin-bottom: 30px;">
        <h3 style="color: #333; font-size: 20px; margin-bottom: 20px; border-left: 4px solid #667eea; padding-left: 12px;">维度分析</h3>
        ${Object.entries(a).map(([o,d])=>{const i=typeof d=="object"?d.value:d;return`
          <div style="margin-bottom: 15px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
              <span style="font-weight: 500; color: #555;">${o} - ${y(o)}</span>
              <span style="font-weight: bold; color: #667eea;">${i}%</span>
            </div>
            <div style="background: #f0f0f0; height: 12px; border-radius: 6px; overflow: hidden;">
              <div style="background: linear-gradient(90deg, #667eea, #764ba2); height: 100%; width: ${i}%;"></div>
            </div>
          </div>
        `}).join("")}
      </div>
    `}if(t.disc_type){const a=t.disc_dimensions||{};n=`
      <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); padding: 30px; border-radius: 12px; color: white; margin-bottom: 30px;">
        <div style="display: flex; align-items: center; gap: 20px;">
          <div style="font-size: 48px; font-weight: bold;">${t.disc_type}</div>
          <div>
            <div style="font-size: 24px; font-weight: bold;">${t.disc_description||"DISC行为风格"}</div>
            <div style="opacity: 0.9; margin-top: 5px;">DISC行为风格测评</div>
          </div>
        </div>
      </div>
      
      <div style="margin-bottom: 30px;">
        <h3 style="color: #333; font-size: 20px; margin-bottom: 20px; border-left: 4px solid #f5576c; padding-left: 12px;">维度分析</h3>
        ${Object.entries(a).map(([o,d])=>{const i=typeof d=="object"?d.value:d;return`
          <div style="margin-bottom: 15px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
              <span style="font-weight: 500; color: #555;">${o}型 - ${b(o)}</span>
              <span style="font-weight: bold; color: #f5576c;">${i}%</span>
            </div>
            <div style="background: #f0f0f0; height: 12px; border-radius: 6px; overflow: hidden;">
              <div style="background: linear-gradient(90deg, #f093fb, #f5576c); height: 100%; width: ${i}%;"></div>
            </div>
          </div>
        `}).join("")}
      </div>
    `}if(t.epq_personality_trait||t.personality_trait||t.epq_dimensions||t.dimensions){const a=t.epq_dimensions||t.dimensions||{};n=`
      <div style="background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); padding: 30px; border-radius: 12px; color: white; margin-bottom: 30px;">
        <div style="display: flex; align-items: center; gap: 20px;">
          <div style="font-size: 36px;">🧠</div>
          <div>
            <div style="font-size: 24px; font-weight: bold;">${t.epq_personality_trait||t.personality_trait||"人格特征"}</div>
            <div style="opacity: 0.9; margin-top: 5px;">EPQ人格测评</div>
          </div>
        </div>
      </div>
      
      <div style="margin-bottom: 30px;">
        <h3 style="color: #333; font-size: 20px; margin-bottom: 20px; border-left: 4px solid #11998e; padding-left: 12px;">维度分析</h3>
        ${Object.entries(a).map(([d,i])=>{const p=i.label||d,c=i.level||"中",v=i.value??i.raw_score??0,f=i.t_score??50;return`
          <div style="background: #f8f9fa; padding: 15px; border-radius: 10px; margin-bottom: 12px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
              <div style="display: flex; align-items: center; gap: 10px;">
                <span style="background: linear-gradient(135deg, #11998e, #38ef7d); color: white; padding: 6px 12px; border-radius: 6px; font-weight: bold;">${d}</span>
                <span style="font-weight: 500; color: #333;">${p}</span>
              </div>
              <span style="padding: 4px 12px; border-radius: 4px; font-size: 13px; font-weight: 500; background: ${c==="高"?"#fee2e2":c==="低"?"#d1fae5":"#fef3c7"}; color: ${c==="高"?"#dc2626":c==="低"?"#059669":"#d97706"};">${c}</span>
            </div>
            <div style="display: flex; gap: 20px; font-size: 14px; color: #666;">
              <span>原始分: ${v}</span>
              <span style="color: #11998e; font-weight: 600;">T分: ${f}</span>
            </div>
            <div style="background: #e2e8f0; height: 8px; border-radius: 4px; overflow: hidden; margin-top: 10px;">
              <div style="background: linear-gradient(90deg, #11998e, #38ef7d); height: 100%; width: ${Math.min(f,100)}%;"></div>
            </div>
          </div>
        `}).join("")}
      </div>
    `}return!n&&e.total_score!==null&&e.total_score!==void 0&&(n=`
      <div style="background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); padding: 30px; border-radius: 12px; color: white; margin-bottom: 30px; text-align: center;">
        <div style="font-size: 48px; font-weight: bold;">${e.total_score}</div>
        <div style="font-size: 16px; opacity: 0.9; margin-top: 5px;">总分</div>
        ${e.grade?`<div style="margin-top: 15px; display: inline-block; padding: 8px 20px; background: rgba(255,255,255,0.2); border-radius: 8px; font-size: 24px; font-weight: bold;">等级: ${e.grade}</div>`:""}
      </div>
    `),`
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Microsoft YaHei', sans-serif; color: #333;">
      <!-- 报告头部 -->
      <div style="text-align: center; margin-bottom: 40px; padding-bottom: 30px; border-bottom: 2px solid #e2e8f0;">
        <h1 style="font-size: 32px; color: #1e293b; margin: 0 0 10px;">测评报告</h1>
        <p style="color: #64748b; font-size: 14px; margin: 0;">${g}</p>
      </div>
      
      <!-- 候选人信息 -->
      <div style="background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); padding: 24px; border-radius: 12px; margin-bottom: 30px;">
        <h3 style="color: #475569; font-size: 16px; margin: 0 0 16px; display: flex; align-items: center; gap: 8px;">
          <span style="display: inline-block; width: 4px; height: 20px; background: #6366f1; border-radius: 2px;"></span>
          候选人信息
        </h3>
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px;">
          <div>
            <div style="color: #94a3b8; font-size: 12px; margin-bottom: 4px;">姓名</div>
            <div style="font-weight: 600; color: #1e293b;">${r}</div>
          </div>
          <div>
            <div style="color: #94a3b8; font-size: 12px; margin-bottom: 4px;">联系方式</div>
            <div style="font-weight: 600; color: #1e293b;">${l}</div>
          </div>
          <div>
            <div style="color: #94a3b8; font-size: 12px; margin-bottom: 4px;">问卷类型</div>
            <div style="font-weight: 600; color: #1e293b;">${s}</div>
          </div>
          <div>
            <div style="color: #94a3b8; font-size: 12px; margin-bottom: 4px;">提交时间</div>
            <div style="font-weight: 600; color: #1e293b;">${h(e.submitted_at)}</div>
          </div>
        </div>
      </div>
      
      <!-- 测评结果 -->
      <div style="margin-bottom: 30px;">
        <h3 style="color: #475569; font-size: 16px; margin: 0 0 16px; display: flex; align-items: center; gap: 8px;">
          <span style="display: inline-block; width: 4px; height: 20px; background: #6366f1; border-radius: 2px;"></span>
          测评结果
        </h3>
        ${n||'<p style="color: #94a3b8;">暂无测评结果</p>'}
      </div>
      
      <!-- 页脚 -->
      <div style="text-align: center; padding-top: 30px; border-top: 1px solid #e2e8f0; color: #94a3b8; font-size: 12px;">
        <p>报告生成时间：${new Date().toLocaleString("zh-CN")}</p>
        <p>TalentLens 人才初步画像智能工具</p>
      </div>
    </div>
  `},_=async(e,t="pdf")=>{try{const r=document.createElement("div");r.style.cssText=`
      position: fixed;
      left: -9999px;
      top: 0;
      width: 800px;
      background: #ffffff;
      padding: 60px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei", sans-serif;
    `,r.innerHTML=u(e),document.body.appendChild(r);const l=await x(r,{scale:2,useCORS:!0,backgroundColor:"#ffffff",logging:!1});document.body.removeChild(r);const g=`测评报告_${e.candidate_name||"未知"}_${e.code}_${new Date().toISOString().slice(0,10)}`;if(t==="image")return new Promise(s=>{l.toBlob(n=>{if(n){const a=URL.createObjectURL(n),o=document.createElement("a");o.href=a,o.download=`${g}.png`,o.click(),URL.revokeObjectURL(a),s({success:!0,message:"图片报告导出成功！"})}else s({success:!1,message:"图片生成失败"})})});{const s=l.toDataURL("image/png"),n=new m({orientation:"portrait",unit:"mm",format:"a4"}),a=210,o=l.height*a/l.width,d=297;let i=o,p=0;for(n.addImage(s,"PNG",0,p,a,o),i-=d;i>0;)p=i-o,n.addPage(),n.addImage(s,"PNG",0,p,a,o),i-=d;return n.save(`${g}.pdf`),{success:!0,message:"PDF报告导出成功！"}}}catch(r){return console.error("导出报告失败:",r),{success:!1,message:"导出报告失败，请重试"}}};export{_ as default,_ as exportReport};
